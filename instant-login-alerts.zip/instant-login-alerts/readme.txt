=== Instant Login Alerts ===
Contributors: developerhabib
Tags: security, login, alert, notification, user, admin,
Requires at least: 5.3
Tested up to: 6.4.1
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html
Stable tag: 1.0

Enhance your WordPress website's security with Instant Login Alerts. This essential plugin provides you with real-time email notifications whenever someone logs into your WP-admin area. Stay informed and vigilant against unauthorized access to your website, giving you the peace of mind you deserve. With Instant Login Alerts, you're always in control of your WordPress security.

== Description ==

A simple and small plugin provides you with real-time email notifications whenever someone logs into your wordpress admin area. Stay informed and get instant notifications via email. Beside this your have option to get notification when someone crate a administrator role in your admin area. You can also get a logged in user ip address. If you want to get the location of the user, you can get the location after putting the ipinfo token. ipinfo token is free and optional. After that save options and you are done. 


== Installation ==

Installation is fairly straight forward. Install it from the WordPress plugin repository. 